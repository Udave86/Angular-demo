import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'sampleApp';
  serachQry = "";
  dataCollection: any[] = [
    {
      "FirstName": "Andrew",
      "LastName" : "Smith",
      "Company":"Accenture",
      "Email":"andrew.s@accenture.com",
      "City":"London"
   },
  
   {
      "FirstName": "James",
      "LastName" : "Peter",
      "Company":"Cognizant",
      "Email":"james.p@cognizant.com",
      "City":"London"
  },
  {
    "FirstName": "Rutvik",
    "LastName" : "Patel",
    "Company":"TCS",
    "Email":"rutvik.p@tcs.com",
    "City":"Gandhinagar"
},
{
  "FirstName": "Lata",
  "LastName" : "Anderson",
  "Company":"Google",
  "Email":"Lata.a@google.com",
  "City":"Chicago"
},
{
  "FirstName": "Smarth",
  "LastName" : "Dave",
  "Company":"Adobe",
  "Email":"smarth.d@adobe.com",
  "City":"Pune"
}
];

  filteredCollection: any[] = [
    {
       "FirstName": "Andrew",
       "LastName" : "Smith",
       "Company":"Accenture",
       "Email":"andrew.s@accenture.com",
       "City":"London"
    },
   
    {
       "FirstName": "James",
       "LastName" : "Peter",
       "Company":"Cognizant",
       "Email":"james.p@cognizant.com",
       "City":"London"
   },
   {
    "FirstName": "Rutvik",
    "LastName" : "Patel",
    "Company":"TCS",
    "Email":"rutvik.p@tcs.com",
    "City":"Gandhinagar"
},
{
  "FirstName": "Lata",
  "LastName" : "Anderson",
  "Company":"Google",
  "Email":"Lata.a@google.com",
  "City":"Chicago"
},
{
  "FirstName": "Smarth",
  "LastName" : "Dave",
  "Company":"Adobe",
  "Email":"smarth.d@adobe.com",
  "City":"Pune"
} 
   ];

onKey(event: any) { // without type info
  debugger;
  this.serachQry = event.target.value;

  this.filteredCollection = [];
  if (this.serachQry == ''){
    for (let index = 0; index < this.dataCollection.length; index++) {
      this.filteredCollection.push(this.dataCollection[index]);
    }
  } else {
    for (let index = 0; index < this.dataCollection.length; index++) {
      if (this.dataCollection[index].FirstName.indexOf(this.serachQry) != -1 ||
      this.dataCollection[index].LastName.indexOf(this.serachQry) != -1 ||
      this.dataCollection[index].Company.indexOf(this.serachQry) != -1 ||
      this.dataCollection[index].Email.indexOf(this.serachQry) != -1 ||
      this.dataCollection[index].City.indexOf(this.serachQry) != -1) {
        this.filteredCollection.push(this.dataCollection[index]);  
      }
    }
  }

}

}


  

